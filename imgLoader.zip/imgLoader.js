const { jsonUtility, Level } = require('rptd-core') 
var PNG = require('png-js')

//a list of all the tiles that can be selected from format is tileid, r,g,b values
var tiles = [[0,96,74,74],[1,86,43,32],[3,84,19,7],[4,49,35,23],[5,135,61,55],[6,113,86,72],
    [7,73,75,60],[8,137,71,42],[9,102,94,88],[10,100,18,0],[11,25,35,37],[12,180,177,172],
    [200,58,44,46],[203,166,72,4],[206,127,64,62],[209,87,28,19]]



function createImg(path = 'testImg.png', level, finish){
    var img = PNG.load(path)
    console.log("image w",img.width,", h",img.height)

    
    img.decodePixels(function(pixels){
        console.log("len"+pixels.length)
        for(let y=0;y<img.height;y++){
            for(let x=0;x<img.width;x++){
                var tile = pixelToTile(x,y,img,pixels)
                //we gotta flip the y axis
                level.addTile({ ID: tile, x:x, y:-y})
            }
        }
        finish()
    })

}

function pixelToTile(x ,y,img,pixels){
    var valuesperPixel = pixels.length/(img.width*img.height)//why do i need this
    //rgb values of the pixel
    var r = pixels[(y*img.width+x)*valuesperPixel]
    var g = pixels[(y*img.width+x)*valuesperPixel+1]
    var b = pixels[(y*img.width+x)*valuesperPixel+2]
    //difference from actual pixel to tile colour
    var diff = 255*3
    var tile = -1 // index of the tile 

    for(let i in tiles){
        
        var rDiff = Math.abs(r-tiles[i][1]) 
        var gDiff = Math.abs(g-tiles[i][2])
        var bDiff = Math.abs(b-tiles[i][3])

        if(diff>rDiff+gDiff+bDiff){
            tile = tiles[i][0]
            diff = rDiff+gDiff+bDiff
        }
    }
    if(tile ===-1){
       console.log("something went wrong. pixel at "+x+","+y+" is -1 with r:"+r+" g:"+g+" b:"+b+" values per pixel:"+valuesperPixel )
    }
    return tile
}

module.exports = {createImg}