const { jsonUtility, Level } = require('rptd-core') 
const img = require('./imgLoader')

const level = new Level({LevelName: "Cool Tech",Creator:"Agoogaloo", Description:"check this out!"}) 
level.createSection({Name:"gottem lol",LevelBounds:{"x":0.0,"y":60.0,"z":1.0,"w":-60.0},spawnPointY:1})


img.createImg('drip.png', level, function(){
        
    //outputting file
    jsonUtility.writeLevelToFile(level, 'C:/Program Files (x86)/Steam/steamapps/common/Ruptured/Ruptured_Data/Data/Levels/Cool Tech.json')
    console.log("outputed file")
})



